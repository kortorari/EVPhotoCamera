# EV Camera / Realme 9 Pro+ investigation build

Standalone Android Camera2 application prototype. This is not yet a replacement for the OPlus Camera app.

## Implemented in source
- Rear camera selection by largest reported sensor pixel array.
- Persistent AE exposure compensation preference, default -2.0 EV; requested UI range -3.0 to +1.0 EV, clamped to the selected camera's reported range and quantized to its compensation step.
- Standard Camera2 HDR scene-mode switch, default OFF, only if the HAL advertises it. This is not a guarantee that OPlus APS HDR is disabled.
- Digital zoom 1.0x to 4.0x.
- JPEG capture to `Pictures/EV Camera`.
- Read-only Camera2 capability inventory for all camera IDs, including vendor keys exposed to a normal app, AE range/step, scene modes, hardware level, pixel array and JPEG output sizes.

## Important limitation
The supplied Realme configuration shows a full APS 3.0 stock pipeline with mode-specific OPlus processing. A normal third-party Camera2 app does not automatically inherit that proprietary APS pipeline. The APK/SDK evidence supplied so far does not establish a public third-party APS entry point. This app therefore does not claim parity for stock HDR, AI scene processing, multi-frame noise reduction, portrait, night, OPlus tone mapping or other proprietary processing.

## Next proof required
Install/run this diagnostic build on the Realme and inspect the private `last_vendor_probe` report. It enumerates only metadata and request keys exposed to this ordinary app UID. Do not write undocumented vendor tags or modify system configuration based on names alone.

## Build
Open in Android Studio with Android Gradle Plugin 8.7.3, compile SDK 35 and Java 17. The current environment does not contain an Android SDK/Gradle installation, so no APK has been built or device-tested here.

Package: `hu.fungexpo.evcamera`  
Min Android: API 26  
Target SDK: 35
