# Realme 9 Pro+ / OPlus camera pipeline: evidence and engineering decision

## Confirmed from the supplied device files

The supplied `oplus_camera_algo_switch_config` declares APS 3.0 (`aps_version: 3`, `aps_mode: 1`, full preview + capture pipeline) and mode-specific algorithm switches.

For rear `common`, entity `id: 0`, the supplied values include:

| APS switch | Value | Meaning for this investigation |
|---|---:|---|
| `aps_algo_hdr` | 1 | HDR algorithm enabled in this APS mode entity |
| `aps_algo_lowlight_hdr` | 1 | low-light HDR enabled |
| `aps_algo_mfll` | 1 | multi-frame low-light processing enabled |
| `aps_algo_ainr` | 1 | AI noise reduction enabled |
| `aps_algo_superphoto` | 1 | Superphoto enabled |
| `aps_algo_upscale` | 1 | upscale path enabled |
| `aps_algo_fusion` | 0 | this switch is disabled in this entity |
| `aps_algo_supernight` | 0 | dedicated Supernight disabled in common mode |

The same configuration has distinct `night`, `portrait`, `professional`, `highDefinition`, `idPhoto`, macro and video modes. Therefore a single generic Camera2 JPEG request cannot be assumed to reproduce every stock mode.

`oplus_camera_aps_config` includes vendor-tag configuration such as `com.oplus.aps.params.asd.force.enable` with value `1`, and zoom/fusion/HDR ranges. These are configuration entries for the device's APS stack. Their presence does not grant a third-party app permission to write them.

## What the APK proves, and what it does not

The supplied OPlus Camera APK is a system product app (`/product/app/OplusCamera`, package `com.oplus.camera`, version `4.040.560`). Its package dump shows signature/privileged permissions and a non-exported `AppConfigSetActivity`. The SDK JAR is a DEX-only file. The APK includes some APS-related JNI helper libraries, but the supplied files do not establish a public, third-party APS capture API or a self-contained APS engine that can be copied into an ordinary app.

The stock APK references global EV identifiers including `com.oplus.global.ev.support`, `com.oplus.feature.global.ev.enable`, `com.oplus.feature.global.ev.value`, and `com.oplus.configure.global.ev.value`. Their presence proves the identifiers exist in stock code, not that a third-party UID can set them or that the HAL honors them.

## Engineering consequence

A normal Camera2 app can use the same sensor and the device's Camera HAL/ISP. It cannot thereby assume access to the stock OPlus APS pipeline, mode graph, proprietary multi-frame capture orchestration, or signature-protected services. Repackaging/re-signing the stock APK does not preserve its system identity.

Accordingly, the current standalone Camera2 app is an EV-control prototype, not a stock-camera clone. It must not claim parity for OPlus HDR/AI/multi-frame/portrait/night/tone-mapping until runtime evidence proves a supported public path.

## Work performed in this revision

`OplusCapabilityProbe` now records, for every camera ID, the standard Camera2 hardware level, sensor pixel array, AE compensation range and step, standard scene modes, JPEG output sizes, and all OPlus/OPPO/APS/HDR/EV/night/portrait/AI-related metadata and capture-request key names visible to an ordinary app. This is read-only. It does not attempt to write undocumented vendor tags or change system files.

The runtime report is saved in the app's private preferences as `last_vendor_probe`. This is the next evidence needed to determine whether this particular firmware exposes a supported third-party control surface.

## Hard boundary

If the runtime probe shows no public APS/vendor capture path and OPlus's service enforces signature/privileged permissions, full stock APS parity in a separately installed, rootless app is not achievable by porting UI or APK code alone. The technically honest fallback is a standalone camera using the exposed HAL/ISP with persistent AE compensation, or a stock-camera integration if the vendor provides a supported extension. Do not promise image-pipeline identity without proof.
