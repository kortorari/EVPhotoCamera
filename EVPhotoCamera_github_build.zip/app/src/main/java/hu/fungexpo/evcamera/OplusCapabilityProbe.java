package hu.fungexpo.evcamera;

import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.graphics.ImageFormat;
import android.util.Range;
import android.util.Rational;
import android.util.Size;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Read-only inventory of the Camera2 contract visible to this ordinary app UID. */
public final class OplusCapabilityProbe {
    private OplusCapabilityProbe() {}

    private static boolean interesting(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        return n.contains("oplus") || n.contains("oppo") || n.contains("aps") ||
               n.contains("hdr") || n.contains("ev") || n.contains("exposure") ||
               n.contains("night") || n.contains("portrait") || n.contains("mfll") ||
               n.contains("ainr") || n.contains("fusion") || n.contains("superphoto") ||
               n.contains("scene") || n.contains("beauty") || n.contains("face");
    }

    public static String inspect(CameraManager manager) throws CameraAccessException {
        StringBuilder out = new StringBuilder();
        out.append("EV CAMERA READ-ONLY CAMERA2 CAPABILITY REPORT\n");
        out.append("This lists only metadata exposed to this non-system application.\n\n");
        for (String id : manager.getCameraIdList()) {
            CameraCharacteristics c = manager.getCameraCharacteristics(id);
            Integer facing = c.get(CameraCharacteristics.LENS_FACING);
            Integer level = c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL);
            android.util.Size pixels = c.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE);
            Range<Integer> ev = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
            Rational step = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP);
            out.append("CAMERA ").append(id).append(" facing=").append(facing)
               .append(" hardwareLevel=").append(level).append('\n');
            out.append("  pixelArray=").append(pixels).append('\n');
            out.append("  AE compensation range index=").append(ev)
               .append(" stepEV=").append(step)
               .append(" actualEV=").append(formatRange(ev, step)).append('\n');
            int[] caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
            out.append("  Camera2 capabilities=").append(array(caps)).append('\n');
            int[] scenes = c.get(CameraCharacteristics.CONTROL_AVAILABLE_SCENE_MODES);
            out.append("  standard scene modes=").append(array(scenes)).append('\n');
            StreamConfigurationMap map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map != null) {
                Size[] jpeg = map.getOutputSizes(ImageFormat.JPEG);
                out.append("  JPEG output sizes:");
                if (jpeg != null) for (Size s : jpeg) out.append(' ').append(s.getWidth()).append('x').append(s.getHeight());
                out.append('\n');
            }
            List<String> characteristics = new ArrayList<>();
            for (CameraCharacteristics.Key<?> key : c.getKeys()) {
                if (interesting(key.getName())) characteristics.add(key.getName());
            }
            Collections.sort(characteristics);
            out.append("  Vendor/algorithm characteristic keys visible to app:\n");
            appendList(out, characteristics);

            List<String> requests = new ArrayList<>();
            List<CaptureRequest.Key<?>> available = c.getAvailableCaptureRequestKeys();
            if (available != null) for (CaptureRequest.Key<?> key : available) {
                if (interesting(key.getName())) requests.add(key.getName());
            }
            Collections.sort(requests);
            out.append("  Vendor/algorithm capture request keys visible to app:\n");
            appendList(out, requests);
            out.append('\n');
        }
        return out.toString();
    }

    private static void appendList(StringBuilder out, List<String> values) {
        if (values.isEmpty()) out.append("    <none exposed to this app UID>\n");
        else for (String value : values) out.append("    ").append(value).append('\n');
    }
    private static String array(int[] values) {
        if (values == null) return "<not reported>";
        StringBuilder b = new StringBuilder("[");
        for (int i = 0; i < values.length; i++) { if (i > 0) b.append(','); b.append(values[i]); }
        return b.append(']').toString();
    }
    private static String formatRange(Range<Integer> range, Rational step) {
        if (range == null || step == null) return "<not reported>";
        return String.format(Locale.US, "%.2f..%.2f", range.getLower() * step.doubleValue(), range.getUpper() * step.doubleValue());
    }
}
