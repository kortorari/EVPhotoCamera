package hu.fungexpo.evcamera;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.provider.MediaStore;
import android.util.Range;
import android.util.Rational;
import android.util.Size;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements TextureView.SurfaceTextureListener {
    private static final int REQUEST_CAMERA = 41;
    private TextureView preview;
    private TextView evText, infoText, zoomText;
    private SeekBar evSeek, zoomSeek;
    private Switch hdrSwitch;
    private Button shutter;

    private CameraManager cameraManager;
    private CameraDevice cameraDevice;
    private CameraCaptureSession captureSession;
    private CaptureRequest.Builder previewBuilder;
    private ImageReader imageReader;
    private HandlerThread cameraThread;
    private Handler cameraHandler;

    private String cameraId;
    private CameraCharacteristics characteristics;
    private Range<Integer> evRange = new Range<>(0, 0);
    private Rational evStep = new Rational(1, 1);
    private double minEv = 0, maxEv = 0;
    private double requestedEv = -2.0;
    private double appliedEv = 0;
    private float zoom = 1f;
    private boolean hdrSupported = false;
    private boolean hdrEnabled = false;
    private boolean cameraReady = false;
    private Size jpegSize = new Size(4000, 3000);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(0xFF000000);
        getWindow().setNavigationBarColor(0xFF000000);
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        requestedEv = getPreferences(MODE_PRIVATE).getFloat("ev", -2.0f);
        hdrEnabled = getPreferences(MODE_PRIVATE).getBoolean("hdr", false);
        buildUi();
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            if (preview.isAvailable()) openCamera();
            else preview.setSurfaceTextureListener(this);
        } else requestPermissions(new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF000000);
        preview = new TextureView(this);
        preview.setSurfaceTextureListener(this);
        root.addView(preview, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(12), dp(18), dp(14));
        panel.setBackgroundColor(0xFF111111);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        evText = text("EV  −2.0", 21, 0xFFFFFFFF);
        top.addView(evText, new LinearLayout.LayoutParams(0, -2, 1f));
        hdrSwitch = new Switch(this);
        hdrSwitch.setText("HDR");
        hdrSwitch.setTextColor(0xFFFFFFFF);
        hdrSwitch.setChecked(hdrEnabled);
        top.addView(hdrSwitch);
        panel.addView(top);

        evSeek = new SeekBar(this);
        evSeek.setMax(40);
        panel.addView(evSeek, new LinearLayout.LayoutParams(-1, -2));
        TextView evScale = text("−3 EV                                      0                                      +1 EV", 11, 0xFFAAAAAA);
        panel.addView(evScale);

        LinearLayout zoomRow = new LinearLayout(this);
        zoomRow.setGravity(Gravity.CENTER_VERTICAL);
        zoomText = text("Zoom 1.0×", 15, 0xFFFFFFFF);
        zoomRow.addView(zoomText, new LinearLayout.LayoutParams(dp(105), -2));
        zoomSeek = new SeekBar(this);
        zoomSeek.setMax(30);
        zoomRow.addView(zoomSeek, new LinearLayout.LayoutParams(0, -2, 1f));
        panel.addView(zoomRow);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        infoText = text("Kamera előkészítése…", 12, 0xFFBBBBBB);
        bottom.addView(infoText, new LinearLayout.LayoutParams(0, -2, 1f));
        shutter = new Button(this);
        shutter.setText("FÉNYKÉP");
        shutter.setTextColor(0xFF111111);
        shutter.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFFFC107));
        bottom.addView(shutter, new LinearLayout.LayoutParams(dp(132), dp(52)));
        panel.addView(bottom);
        root.addView(panel, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);

        evSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                requestedEv = -3.0 + p * 0.1;
                applyEvFromUi();
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        zoomSeek.setProgress(0);
        zoomSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                zoom = 1f + p / 10f;
                zoomText.setText(String.format(Locale.getDefault(), "Zoom %.1f×", zoom));
                updatePreviewRequest();
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        hdrSwitch.setOnCheckedChangeListener((button, checked) -> {
            hdrEnabled = checked;
            getPreferences(MODE_PRIVATE).edit().putBoolean("hdr", checked).apply();
            if (checked && !hdrSupported) {
                hdrSwitch.setChecked(false);
                hdrEnabled = false;
                Toast.makeText(this, "A kamera HAL nem hirdet szabványos HDR-jelenetmódot.", Toast.LENGTH_LONG).show();
                return;
            }
            updatePreviewRequest();
        });
        shutter.setOnClickListener(v -> captureStill());
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void startCameraThread() {
        cameraThread = new HandlerThread("EV-Camera"); cameraThread.start(); cameraHandler = new Handler(cameraThread.getLooper());
    }
    private void stopCameraThread() {
        if (cameraThread != null) { cameraThread.quitSafely(); try { cameraThread.join(); } catch (InterruptedException ignored) {} cameraThread = null; cameraHandler = null; }
    }

    private void openCamera() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        startCameraThread();
        try {
            cameraId = chooseMainRearCamera();
            if (cameraId == null) throw new IllegalStateException("Nem található hátlapi kamera.");
            characteristics = cameraManager.getCameraCharacteristics(cameraId);
            evRange = characteristics.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
            evStep = characteristics.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP);
            if (evRange == null || evStep == null) { evRange = new Range<>(0,0); evStep = new Rational(1,1); }
            minEv = evRange.getLower() * evStep.doubleValue();
            maxEv = evRange.getUpper() * evStep.doubleValue();
            int[] scenes = characteristics.get(CameraCharacteristics.CONTROL_AVAILABLE_SCENE_MODES);
            hdrSupported = scenes != null && contains(scenes, CameraMetadata.CONTROL_SCENE_MODE_HDR);
            if (!hdrSupported && hdrEnabled) { hdrEnabled = false; getPreferences(MODE_PRIVATE).edit().putBoolean("hdr", false).apply(); }
            hdrSwitch.setChecked(hdrEnabled);
            requestedEv = clamp(requestedEv, minEv, maxEv);
            setEvSeekFromValue(requestedEv);
            StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map != null) {
                Size[] sizes = map.getOutputSizes(ImageFormat.JPEG);
                if (sizes != null && sizes.length > 0) jpegSize = chooseJpegSize(sizes);
            }
            String baseInfo = String.format(Locale.getDefault(), "EV %.2f…%.2f  ·  HDR %s", minEv, maxEv, hdrSupported ? "elérhető" : "nem támogatott");
            String vendorInfo = OplusCapabilityProbe.inspect(cameraManager);
            getPreferences(MODE_PRIVATE).edit().putString("last_vendor_probe", vendorInfo).apply();
            infoText.setText(baseInfo + "  ·  OPlus kulcsok: " + (hasExposedKeys(vendorInfo) ? "felderítve" : "nincsenek"));
            cameraManager.openCamera(cameraId, stateCallback, cameraHandler);
        } catch (Exception e) { showError("Kameraindítás: " + e.getMessage()); }
    }

    private String chooseMainRearCamera() throws CameraAccessException {
        String best = null; long bestArea = -1;
        for (String id : cameraManager.getCameraIdList()) {
            CameraCharacteristics c = cameraManager.getCameraCharacteristics(id);
            Integer facing = c.get(CameraCharacteristics.LENS_FACING);
            if (facing == null || facing != CameraCharacteristics.LENS_FACING_BACK) continue;
            android.util.Size size = c.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE);
            long area = size == null ? 0 : (long)size.getWidth() * size.getHeight();
            if (area > bestArea) { bestArea = area; best = id; }
        }
        return best;
    }
    private Size chooseJpegSize(Size[] sizes) {
        Size best = sizes[0]; long bestArea = 0;
        for (Size s : sizes) {
            long area = (long)s.getWidth() * s.getHeight();
            if (area > bestArea && area <= 48_000_000L) { best = s; bestArea = area; }
        }
        return best;
    }
    /** True, ha a jelentésben van legalább egy valódi kulcsnév (a "<none exposed ...>" sorok nem számítanak). */
    private static boolean hasExposedKeys(String report) {
        for (String line : report.split("\n")) {
            if (line.startsWith("    ") && !line.startsWith("    <")) return true;
        }
        return false;
    }
    private boolean contains(int[] values, int value) { for (int v : values) if (v == value) return true; return false; }
    private double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }

    private void setEvSeekFromValue(double value) {
        double p = clamp((value + 3.0) * 10.0, 0, 40);
        evSeek.setProgress((int)Math.round(p));
        applyEvFromUi();
    }
    private int evCompensationIndex() {
        if (evStep == null || evStep.doubleValue() <= 0) return 0;
        int index = (int)Math.round(requestedEv / evStep.doubleValue());
        return Math.max(evRange.getLower(), Math.min(evRange.getUpper(), index));
    }
    private void applyEvFromUi() {
        int index = evCompensationIndex();
        appliedEv = index * evStep.doubleValue();
        evText.setText(String.format(Locale.getDefault(), "EV  %+.1f", appliedEv));
        getPreferences(MODE_PRIVATE).edit().putFloat("ev", (float)requestedEv).apply();
        updatePreviewRequest();
    }

    private final CameraDevice.StateCallback stateCallback = new CameraDevice.StateCallback() {
        @Override public void onOpened(CameraDevice camera) {
            cameraDevice = camera; createSession();
        }
        @Override public void onDisconnected(CameraDevice camera) { camera.close(); cameraDevice = null; cameraReady = false; }
        @Override public void onError(CameraDevice camera, int error) { camera.close(); cameraDevice = null; cameraReady = false; showError("Kamera hiba: " + error); }
    };

    private void createSession() {
        try {
            if (preview.getSurfaceTexture() == null || cameraDevice == null) return;
            SurfaceTexture texture = preview.getSurfaceTexture();
            texture.setDefaultBufferSize(1920, 1080);
            Surface previewSurface = new Surface(texture);
            imageReader = ImageReader.newInstance(jpegSize.getWidth(), jpegSize.getHeight(), ImageFormat.JPEG, 2);
            imageReader.setOnImageAvailableListener(reader -> {
                Image image = null;
                try {
                    image = reader.acquireNextImage();
                    if (image == null) return;
                    ByteBuffer buffer = image.getPlanes()[0].getBuffer();
                    byte[] bytes = new byte[buffer.remaining()]; buffer.get(bytes);
                    saveJpeg(bytes);
                } catch (Exception e) { showError("Mentési hiba: " + e.getMessage()); }
                finally { if (image != null) image.close(); }
            }, cameraHandler);
            cameraDevice.createCaptureSession(Arrays.asList(previewSurface, imageReader.getSurface()), new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession session) {
                    captureSession = session;
                    try {
                        previewBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                        previewBuilder.addTarget(previewSurface);
                        applyCommonControls(previewBuilder);
                        session.setRepeatingRequest(previewBuilder.build(), null, cameraHandler);
                        cameraReady = true;
                    } catch (CameraAccessException e) { showError(e.getMessage()); }
                }
                @Override public void onConfigureFailed(CameraCaptureSession session) { showError("A kamera előnézeti munkamenete nem indítható."); }
            }, cameraHandler);
        } catch (CameraAccessException e) { showError(e.getMessage()); }
    }

    private void applyCommonControls(CaptureRequest.Builder builder) {
        builder.set(CaptureRequest.CONTROL_MODE, hdrEnabled && hdrSupported ? CaptureRequest.CONTROL_MODE_USE_SCENE_MODE : CaptureRequest.CONTROL_MODE_AUTO);
        builder.set(CaptureRequest.CONTROL_SCENE_MODE, hdrEnabled && hdrSupported ? CameraMetadata.CONTROL_SCENE_MODE_HDR : CameraMetadata.CONTROL_SCENE_MODE_DISABLED);
        builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
        builder.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evCompensationIndex());
        builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
        builder.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO);
        builder.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF);
        builder.set(CaptureRequest.SCALER_CROP_REGION, cropRegion());
    }
    private Rect cropRegion() {
        Rect active = characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
        if (active == null) return null;
        int w = (int)(active.width() / zoom), h = (int)(active.height() / zoom);
        int left = active.centerX() - w / 2, top = active.centerY() - h / 2;
        return new Rect(left, top, left + w, top + h);
    }
    private void updatePreviewRequest() {
        if (!cameraReady || captureSession == null || previewBuilder == null) return;
        try { applyCommonControls(previewBuilder); captureSession.setRepeatingRequest(previewBuilder.build(), null, cameraHandler); }
        catch (CameraAccessException e) { showError(e.getMessage()); }
    }

    private void captureStill() {
        if (!cameraReady || cameraDevice == null || captureSession == null) { Toast.makeText(this, "A kamera még nem áll készen.", Toast.LENGTH_SHORT).show(); return; }
        try {
            CaptureRequest.Builder still = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            still.addTarget(imageReader.getSurface());
            applyCommonControls(still);
            still.set(CaptureRequest.JPEG_ORIENTATION, jpegOrientation());
            shutter.setEnabled(false);
            captureSession.capture(still.build(), new CameraCaptureSession.CaptureCallback() {
                @Override public void onCaptureCompleted(CameraCaptureSession session, CaptureRequest request, android.hardware.camera2.TotalCaptureResult result) {
                    runOnUiThread(() -> shutter.setEnabled(true));
                }
                @Override public void onCaptureFailed(CameraCaptureSession session, CaptureRequest request, android.hardware.camera2.CaptureFailure failure) {
                    runOnUiThread(() -> { shutter.setEnabled(true); showError("A felvétel nem sikerült."); });
                }
            }, cameraHandler);
        } catch (CameraAccessException e) { shutter.setEnabled(true); showError(e.getMessage()); }
    }
    private int jpegOrientation() {
        int rotation = getWindowManager().getDefaultDisplay().getRotation();
        int degrees = rotation == Surface.ROTATION_90 ? 90 : rotation == Surface.ROTATION_180 ? 180 : rotation == Surface.ROTATION_270 ? 270 : 0;
        Integer sensor = characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
        return ((sensor == null ? 90 : sensor) - degrees + 360) % 360;
    }
    private void saveJpeg(byte[] bytes) throws Exception {
        String name = "EV_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".jpg";
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/EV Camera");
        Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IllegalStateException("Nem hozható létre a kép.");
        try (OutputStream out = getContentResolver().openOutputStream(uri)) { if (out == null) throw new IllegalStateException("Nem nyitható meg a képfájl."); out.write(bytes); }
        runOnUiThread(() -> Toast.makeText(this, "Mentve: " + name, Toast.LENGTH_SHORT).show());
    }
    private void showError(String message) { runOnUiThread(() -> Toast.makeText(this, message == null ? "Ismeretlen kamera-hiba" : message, Toast.LENGTH_LONG).show()); }

    @Override public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) { if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED && cameraDevice == null) openCamera(); }
    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {}
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) { return true; }
    @Override public void onSurfaceTextureUpdated(SurfaceTexture surface) {}

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_CAMERA && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            if (preview.isAvailable()) openCamera(); else preview.setSurfaceTextureListener(this);
        } else showError("A kameraengedély szükséges a fényképezéshez.");
    }
    @Override protected void onResume() { super.onResume(); if (preview != null && preview.isAvailable() && cameraDevice == null && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) openCamera(); }
    @Override protected void onPause() { closeCamera(); super.onPause(); }
    private void closeCamera() {
        try { if (captureSession != null) { captureSession.close(); captureSession = null; } if (cameraDevice != null) { cameraDevice.close(); cameraDevice = null; } if (imageReader != null) { imageReader.close(); imageReader = null; } cameraReady = false; }
        finally { stopCameraThread(); }
    }
}
